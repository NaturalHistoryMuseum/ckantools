#!/usr/bin/env python3
# encoding: utf-8
#
# This file is part of ckantools
# Created by the Natural History Museum in London, UK

import setuptools

if __name__ == "__main__":
    setuptools.setup()
