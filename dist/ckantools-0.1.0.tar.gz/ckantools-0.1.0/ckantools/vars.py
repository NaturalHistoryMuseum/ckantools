# !/usr/bin/env python
# encoding: utf-8

auth_valid = {'success': True}
auth_invalid = {'success': False}
